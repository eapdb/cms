<?php
require_once '../config.php';

// Check if logged in
if (!is_admin_logged_in()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Handle delete operation
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ?");
        $stmt->execute([$id]);
        $success = 'Article deleted successfully.';
    } catch (PDOException $e) {
        $error = 'Deletion failed: ' . $e->getMessage();
    }
}

// Handle status change
if (isset($_GET['action']) && $_GET['action'] == 'toggle_status' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("SELECT status FROM articles WHERE id = ?");
        $stmt->execute([$id]);
        $article = $stmt->fetch();
        
        if ($article) {
            $new_status = $article['status'] == 'published' ? 'draft' : 'published';
            $stmt = $pdo->prepare("UPDATE articles SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $id]);
            $success = 'Article status updated.';
        }
    } catch (PDOException $e) {
        $error = 'Update failed: ' . $e->getMessage();
    }
}

// Get article list
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

try {
    // Get total number of articles
    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM articles");
    $total_stmt->execute();
    $total_articles = $total_stmt->fetchColumn();
    $total_pages = ceil($total_articles / $limit);

    // Get current page articles
    $stmt = $pdo->prepare("
        SELECT a.*, au.username as author_name 
        FROM articles a 
        LEFT JOIN admin_users au ON a.author_id = au.id 
        ORDER BY a.created_at DESC 
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$limit, $offset]);
    $articles = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Failed to retrieve articles: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article Management - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="admin-sidebar">
        <h3>Admin Panel</h3>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="articles.php">Article Management</a></li>
            <li><a href="users.php">User Management</a></li>
            <li><a href="settings.php">Website Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content Area -->
    <div class="admin-content">
        <!-- Top Navigation -->
        <div class="admin-header">
            <h1>Article Management</h1>
            <div>
                <a href="article_edit.php" class="btn btn-primary">Add New Article</a>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Article List -->
        <div class="card">
            <div class="card-header">
                All Articles (<?php echo $total_articles; ?> total)
            </div>
            <div class="card-body">
                <?php if (empty($articles)): ?>
                    <p>No articles found. <a href="article_edit.php">Add your first article now</a></p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($articles as $article): ?>
                                <tr>
                                    <td><?php echo $article['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($article['title']); ?></strong>
                                        <br>
                                        <small style="color: #666;">
                                            <?php 
                                            $content = strip_tags($article['content']);
                                            echo htmlspecialchars(mb_substr($content, 0, 100)) . (mb_strlen($content) > 100 ? '...' : '');
                                            ?>
                                        </small>
                                    </td>
                                    <td><?php echo htmlspecialchars($article['author_name'] ?? 'Unknown'); ?></td>
                                    <td>
                                        <span class="btn btn-sm <?php echo $article['status'] == 'published' ? 'btn-success' : 'btn-warning'; ?>">
                                            <?php echo $article['status'] == 'published' ? 'Published' : 'Draft'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['created_at'])); ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['updated_at'])); ?></td>
                                    <td>
                                        <a href="../article.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-secondary" target="_blank">Preview</a>
                                        <a href="article_edit.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                        <a href="?action=toggle_status&id=<?php echo $article['id']; ?>" 
                                           class="btn btn-sm <?php echo $article['status'] == 'published' ? 'btn-warning' : 'btn-success'; ?>"
                                           onclick="return confirm('Are you sure you want to change the article status?')">
                                            <?php echo $article['status'] == 'published' ? 'Set to Draft' : 'Publish'; ?>
                                        </a>
                                        <a href="?action=delete&id=<?php echo $article['id']; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Are you sure you want to delete this article? This action cannot be undone!')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>">Previous</a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?>">Next</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Confirmation dialog for deletion (Note: For a real application, consider a custom modal instead of alert/confirm)
        function confirmDelete() {
            return confirm('Are you sure you want to delete this article? This action cannot be undone!');
        }
    </script>
</body>
</html>