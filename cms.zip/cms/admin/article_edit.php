<?php
require_once '../config.php';

// Check if logged in
if (!is_admin_logged_in()) {
    redirect('login.php');
}

$article = [
    'id' => '',
    'title' => '',
    'content' => '',
    'status' => 'draft'
];
$is_edit = false;

// Edit mode: Get article data
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $article = $stmt->fetch();
    if ($article) {
        $is_edit = true;
    } else {
        $error = "Article not found.";
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'] === 'published' ? 'published' : 'draft';

    if ($title === '' || $content === '') {
        $error = "Title and content cannot be empty.";
    } else {
        if ($is_edit) {
            // Update
            $stmt = $pdo->prepare("UPDATE articles SET title=?, content=?, status=? WHERE id=?");
            $stmt->execute([$title, $content, $status, $article['id']]);
            $success = "Article updated successfully!";
        } else {
            // Add new
            $stmt = $pdo->prepare("INSERT INTO articles (title, content, status, author_id, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $content, $status, $_SESSION['admin_id']]);
            $success = "Article added successfully!";
            // Clear form
            $article = ['id'=>'', 'title'=>'', 'content'=>'', 'status'=>'draft'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $is_edit ? 'Edit Article' : 'Add New Article'; ?> - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <h3>Admin Panel</h3>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="articles.php">Article Management</a></li>
            <li><a href="users.php">User Management</a></li>
            <li><a href="settings.php">Website Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <div class="admin-header">
            <h1><?php echo $is_edit ? 'Edit Article' : 'Add New Article'; ?></h1>
            <a href="articles.php" class="btn btn-sm">Back to Articles List</a>
        </div>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php elseif (!empty($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($article['title']); ?>" required>
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea name="content" class="form-control" rows="10" required><?php echo htmlspecialchars($article['content']); ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="draft" <?php if($article['status']=='draft') echo 'selected'; ?>>Draft</option>
                    <option value="published" <?php if($article['status']=='published') echo 'selected'; ?>>Published</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo $is_edit ? 'Update' : 'Add'; ?></button>
        </form>
    </div>
</body>
</html>