<?php
require_once '../config.php';

// Check if logged in
if (!is_admin_logged_in()) {
    redirect('login.php');
}

// Get statistics
try {
    $total_articles_stmt = $pdo->query("SELECT COUNT(*) FROM articles");
    $total_articles = $total_articles_stmt->fetchColumn();
    
    $published_articles_stmt = $pdo->query("SELECT COUNT(*) FROM articles WHERE status = 'published'");
    $published_articles = $published_articles_stmt->fetchColumn();
    
    $total_users_stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $total_users = $total_users_stmt->fetchColumn();
    
    // Latest Articles
    $recent_articles_stmt = $pdo->prepare("
        SELECT a.*, au.username as author_name 
        FROM articles a 
        LEFT JOIN admin_users au ON a.author_id = au.id 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ");
    $recent_articles_stmt->execute();
    $recent_articles = $recent_articles_stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Failed to retrieve data: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo htmlspecialchars(get_site_setting('site_title')); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <h3>Admin Panel</h3>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="articles.php">Article Management</a></li>
            <li><a href="users.php">User Management</a></li>
            <li><a href="settings.php">Website Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="admin-content">
        <div class="admin-header">
            <h1>Admin Dashboard</h1>
            <div>
                Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?> |
                <a href="../index.php" target="_blank">View Frontend</a> |
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
            <div class="card">
                <div class="card-header">Total Articles</div>
                <div class="card-body">
                    <h2 style="color: #3498db; margin: 0;"><?php echo $total_articles ?? 0; ?></h2>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">Published Articles</div>
                <div class="card-body">
                    <h2 style="color: #27ae60; margin: 0;"><?php echo $published_articles ?? 0; ?></h2>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">Registered Users</div>
                <div class="card-body">
                    <h2 style="color: #f39c12; margin: 0;"><?php echo $total_users ?? 0; ?></h2>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                Latest Articles
                <a href="articles.php" class="btn btn-sm" style="float: right;">View All</a>
            </div>
            <div class="card-body">
                <?php if (empty($recent_articles)): ?>
                    <p>No articles found.</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_articles as $article): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($article['title']); ?></td>
                                    <td><?php echo htmlspecialchars($article['author_name'] ?? 'Unknown'); ?></td>
                                    <td>
                                        <span class="<?php echo $article['status'] == 'published' ? 'btn-success' : 'btn-warning'; ?> btn-sm">
                                            <?php echo $article['status'] == 'published' ? 'Published' : 'Draft'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['created_at'])); ?></td>
                                    <td>
                                        <a href="article_edit.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">Quick Actions</div>
            <div class="card-body">
                <a href="article_edit.php" class="btn btn-primary">Add New Article</a>
                <a href="users.php" class="btn btn-success">Manage Users</a>
                <a href="settings.php" class="btn btn-warning">Website Settings</a>
            </div>
        </div>
    </div>
</body>
</html>