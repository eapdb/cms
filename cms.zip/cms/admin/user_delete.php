<?php
require_once '../config.php';

// Check if admin is logged in
if (!is_admin_logged_in()) {
    redirect('login.php');
}

// If an ID is provided and it's a number, delete the user
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
}

// Redirect back to the user list page
redirect('users.php');
?>