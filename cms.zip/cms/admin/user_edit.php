<?php
require_once '../config.php';

// Check if the user is logged in as an admin
if (!is_admin_logged_in()) {
    redirect('login.php');
}

// Ensure an ID is provided and is numeric
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('users.php'); // Redirect if no valid ID
}

// Fetch user data based on ID
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_GET['id']]);
$user = $stmt->fetch();

// If user not found, redirect back to user list
if (!$user) {
    redirect('users.php');
}

// Initialize error variable
$error = '';

// Handle form submission for updating user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = $_POST['password']; // New password, can be empty

    // Validate required fields
    if ($username === '' || $email === '') {
        $error = "Username and Email cannot be empty.";
    } else {
        // Prepare SQL update statement
        if ($password !== '') {
            // Update password if a new one is provided
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET username=?, email=?, role=?, password=? WHERE id=?");
            $stmt->execute([$username, $email, $role, $hash, $user['id']]);
        } else {
            // Update without changing password
            $stmt = $pdo->prepare("UPDATE users SET username=?, email=?, role=? WHERE id=?");
            $stmt->execute([$username, $email, $role, $user['id']]);
        }
        // Redirect back to user list after update
        redirect('users.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-sidebar">
        <h3>Admin Panel</h3>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="articles.php">Article Management</a></li>
            <li><a href="users.php">User Management</a></li>
            <li><a href="settings.php">Website Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="admin-content">
        <div class="admin-header">
            <h1>Edit User</h1>
            <a href="users.php" class="btn btn-sm">Back to Users List</a>
        </div>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select id="role" name="role" class="form-control">
                    <option value="user" <?php if($user['role']=='user') echo 'selected'; ?>>Normal User</option>
                    <option value="admin" <?php if($user['role']=='admin') echo 'selected'; ?>>Administrator</option>
                </select>
            </div>
            <div class="form-group">
                <label for="password">New Password (leave blank if not changing)</label>
                <input type="password" id="password" name="password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
</body>
</html>